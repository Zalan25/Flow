﻿namespace QuestionBankClient
{
    partial class UC_TypeSelector
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTypeHeader = new System.Windows.Forms.Label();
            this.btnTF = new System.Windows.Forms.Button();
            this.btnMulti = new System.Windows.Forms.Button();
            this.btnShort = new System.Windows.Forms.Button();
            this.pnlleft = new System.Windows.Forms.Panel();
            this.pnlCenter = new System.Windows.Forms.Panel();
            this.flpQuestionList = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlright = new System.Windows.Forms.Panel();
            this.lblSetHeader = new System.Windows.Forms.Label();
            this.cmbRandomLanguage = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddRandom = new System.Windows.Forms.Button();
            this.numRandomCount = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnOpenBank = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlleft.SuspendLayout();
            this.pnlCenter.SuspendLayout();
            this.pnlright.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRandomCount)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTypeHeader
            // 
            this.lblTypeHeader.AutoSize = true;
            this.lblTypeHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTypeHeader.Location = new System.Drawing.Point(16, 15);
            this.lblTypeHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTypeHeader.Name = "lblTypeHeader";
            this.lblTypeHeader.Size = new System.Drawing.Size(250, 45);
            this.lblTypeHeader.TabIndex = 0;
            this.lblTypeHeader.Text = "Kérdés Típúsok";
            // 
            // btnTF
            // 
            this.btnTF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTF.Location = new System.Drawing.Point(24, 262);
            this.btnTF.Margin = new System.Windows.Forms.Padding(4);
            this.btnTF.Name = "btnTF";
            this.btnTF.Size = new System.Drawing.Size(290, 85);
            this.btnTF.TabIndex = 10;
            this.btnTF.Text = "Igaz-Hamis";
            this.btnTF.UseVisualStyleBackColor = true;
            this.btnTF.Click += new System.EventHandler(this.btnTF_Click);
            // 
            // btnMulti
            // 
            this.btnMulti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMulti.Location = new System.Drawing.Point(21, 169);
            this.btnMulti.Margin = new System.Windows.Forms.Padding(4);
            this.btnMulti.Name = "btnMulti";
            this.btnMulti.Size = new System.Drawing.Size(290, 85);
            this.btnMulti.TabIndex = 8;
            this.btnMulti.Text = "Több helyes";
            this.btnMulti.UseVisualStyleBackColor = true;
            this.btnMulti.Click += new System.EventHandler(this.btnMulti_Click);
            // 
            // btnShort
            // 
            this.btnShort.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShort.Location = new System.Drawing.Point(24, 76);
            this.btnShort.Margin = new System.Windows.Forms.Padding(4);
            this.btnShort.Name = "btnShort";
            this.btnShort.Size = new System.Drawing.Size(290, 85);
            this.btnShort.TabIndex = 6;
            this.btnShort.Text = "Rövid válasz";
            this.btnShort.UseVisualStyleBackColor = true;
            this.btnShort.Click += new System.EventHandler(this.btnShort_Click);
            // 
            // pnlleft
            // 
            this.pnlleft.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlleft.Controls.Add(this.button2);
            this.pnlleft.Controls.Add(this.button1);
            this.pnlleft.Controls.Add(this.btnOpenBank);
            this.pnlleft.Controls.Add(this.label2);
            this.pnlleft.Controls.Add(this.label3);
            this.pnlleft.Controls.Add(this.numRandomCount);
            this.pnlleft.Controls.Add(this.btnAddRandom);
            this.pnlleft.Controls.Add(this.label1);
            this.pnlleft.Controls.Add(this.cmbRandomLanguage);
            this.pnlleft.Controls.Add(this.btnShort);
            this.pnlleft.Controls.Add(this.btnMulti);
            this.pnlleft.Controls.Add(this.btnTF);
            this.pnlleft.Controls.Add(this.lblTypeHeader);
            this.pnlleft.Location = new System.Drawing.Point(0, 0);
            this.pnlleft.Margin = new System.Windows.Forms.Padding(4);
            this.pnlleft.Name = "pnlleft";
            this.pnlleft.Size = new System.Drawing.Size(352, 1000);
            this.pnlleft.TabIndex = 0;
            // 
            // pnlCenter
            // 
            this.pnlCenter.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlCenter.BackColor = System.Drawing.SystemColors.Window;
            this.pnlCenter.Controls.Add(this.flpQuestionList);
            this.pnlCenter.Location = new System.Drawing.Point(356, 0);
            this.pnlCenter.Margin = new System.Windows.Forms.Padding(4);
            this.pnlCenter.Name = "pnlCenter";
            this.pnlCenter.Size = new System.Drawing.Size(473, 999);
            this.pnlCenter.TabIndex = 1;
            // 
            // flpQuestionList
            // 
            this.flpQuestionList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.flpQuestionList.AutoScroll = true;
            this.flpQuestionList.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.flpQuestionList.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.flpQuestionList.Location = new System.Drawing.Point(3, 0);
            this.flpQuestionList.Name = "flpQuestionList";
            this.flpQuestionList.Size = new System.Drawing.Size(470, 996);
            this.flpQuestionList.TabIndex = 0;
            this.flpQuestionList.WrapContents = false;
            this.flpQuestionList.Paint += new System.Windows.Forms.PaintEventHandler(this.flpQuestionList_Paint);
            this.flpQuestionList.Resize += new System.EventHandler(this.flpQuestionList_Resize);
            // 
            // pnlright
            // 
            this.pnlright.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlright.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pnlright.Controls.Add(this.lblSetHeader);
            this.pnlright.Location = new System.Drawing.Point(835, 0);
            this.pnlright.Margin = new System.Windows.Forms.Padding(4);
            this.pnlright.Name = "pnlright";
            this.pnlright.Size = new System.Drawing.Size(732, 999);
            this.pnlright.TabIndex = 2;
            this.pnlright.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlright_Paint);
            // 
            // lblSetHeader
            // 
            this.lblSetHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSetHeader.AutoSize = true;
            this.lblSetHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblSetHeader.Location = new System.Drawing.Point(2, 23);
            this.lblSetHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSetHeader.Name = "lblSetHeader";
            this.lblSetHeader.Size = new System.Drawing.Size(239, 31);
            this.lblSetHeader.TabIndex = 0;
            this.lblSetHeader.Text = "Kérdés beállítása";
            // 
            // cmbRandomLanguage
            // 
            this.cmbRandomLanguage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRandomLanguage.FormattingEnabled = true;
            this.cmbRandomLanguage.Location = new System.Drawing.Point(39, 671);
            this.cmbRandomLanguage.Name = "cmbRandomLanguage";
            this.cmbRandomLanguage.Size = new System.Drawing.Size(245, 33);
            this.cmbRandomLanguage.TabIndex = 11;
            this.cmbRandomLanguage.SelectedIndexChanged += new System.EventHandler(this.cmbRandomLanguage_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 480);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 45);
            this.label1.TabIndex = 12;
            this.label1.Text = "Random kérdések";
            // 
            // btnAddRandom
            // 
            this.btnAddRandom.Location = new System.Drawing.Point(42, 710);
            this.btnAddRandom.Name = "btnAddRandom";
            this.btnAddRandom.Size = new System.Drawing.Size(242, 94);
            this.btnAddRandom.TabIndex = 13;
            this.btnAddRandom.Text = "Kérdések hozzáadása";
            this.btnAddRandom.UseVisualStyleBackColor = true;
            this.btnAddRandom.Click += new System.EventHandler(this.btnAddRandom_Click);
            // 
            // numRandomCount
            // 
            this.numRandomCount.Location = new System.Drawing.Point(39, 573);
            this.numRandomCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numRandomCount.Name = "numRandomCount";
            this.numRandomCount.Size = new System.Drawing.Size(237, 31);
            this.numRandomCount.TabIndex = 14;
            this.numRandomCount.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(41, 625);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nyelv";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(41, 539);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(154, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mennyiség";
            // 
            // btnOpenBank
            // 
            this.btnOpenBank.Location = new System.Drawing.Point(47, 822);
            this.btnOpenBank.Name = "btnOpenBank";
            this.btnOpenBank.Size = new System.Drawing.Size(242, 94);
            this.btnOpenBank.TabIndex = 15;
            this.btnOpenBank.Text = "Kérdésbank";
            this.btnOpenBank.UseVisualStyleBackColor = true;
            this.btnOpenBank.Click += new System.EventHandler(this.btnOpenBank_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(24, 448);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(290, 85);
            this.button1.TabIndex = 16;
            this.button1.Text = "Feleletválasztós";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Location = new System.Drawing.Point(24, 355);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(290, 85);
            this.button2.TabIndex = 17;
            this.button2.Text = "Essay";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // UC_TypeSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlright);
            this.Controls.Add(this.pnlCenter);
            this.Controls.Add(this.pnlleft);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "UC_TypeSelector";
            this.Size = new System.Drawing.Size(1567, 1000);
            this.Load += new System.EventHandler(this.UC_TypeSelector_Load_1);
            this.pnlleft.ResumeLayout(false);
            this.pnlleft.PerformLayout();
            this.pnlCenter.ResumeLayout(false);
            this.pnlright.ResumeLayout(false);
            this.pnlright.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRandomCount)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTypeHeader;
        private System.Windows.Forms.Button btnTF;
        private System.Windows.Forms.Button btnMulti;
        private System.Windows.Forms.Button btnShort;
        private System.Windows.Forms.Panel pnlleft;
        private System.Windows.Forms.Panel pnlCenter;
        private System.Windows.Forms.Label lblSetHeader;
        public System.Windows.Forms.Panel pnlright;
        private System.Windows.Forms.FlowLayoutPanel flpQuestionList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numRandomCount;
        private System.Windows.Forms.Button btnAddRandom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbRandomLanguage;
        private System.Windows.Forms.Button btnOpenBank;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
    }
}
